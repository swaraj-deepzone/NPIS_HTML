<!-- Header Start -->
@include('layouts.header_latest')


<!-- Sidebar Start -->
@include('layouts.sidebar_latest')

<!-- Topbar Start -->
@include('layouts.topbar_latest')


<!-- content -->
@yield('content')

<!-- Footer Start -->
@include('layouts.footer_latest')

