<!-- Mainbody_conatiner Starts -->
<div class="Mainbody_conatiner">
        <!-- HEADER Section starts -->
        <header>
          <nav>
            <div class="nav_bar">
              <div class="Nav_left_Input_content">
                <div class="d-flex">
                  <input type="text" class="form-control" />
                  <button class="btn btn-outline-secondary" type="button">
                    Cari
                  </button>
                </div>
              </div>
              <div class="Nav_right_content d-flex">
                <div class="Nav_right_img_content d-flex">
                  <img
                    src="assets/images/Jata-Malaysia-Vector-01 6.png"
                    alt="Jata-Malaysia"
                  />
                  <img
                    src="assets/images/logo-jab-pengairan-saliran-msia__400x293 6.png"
                    alt="jab-pengairan-saliran-msia"
                  />
                  <img src="assets/images/coolicon.png" alt="coolicon" />
                  <a class="nav-link" data-bs-toggle="offcanvas" href="#theme-settings-offcanvas">
                    <img src="assets/images/Icon Settings.png" alt="Settings" />
                  </a>
                  <a class="nav-link" href="" data-toggle="fullscreen">
                    <img src="assets/images/Vector-11.png" alt="" />
                  </a>
                </div>
                <div class="profile_container d-flex">
                  <div class="profile_content">
                    <ul>
                      <li class="dropdown notification-list"  onclick="myFunction()">
                            <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false"
                                aria-expanded="false">
                                <span class="account-user-avatar"> 
                                    <img src="assets/images/Admin pic.png" alt="user-image" class="rounded-circle">
                                </span>
                                <span>
                                    <span class="account-user-name">Aiman Daniel</span>
                                    <span class="account-position">Pentadbir</span>
                                </span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown" id="profile_list">
                                <!-- item-->
                                <div class=" dropdown-header noti-title">
                                    <h6 class="text-overflow m-0">Welcome !</h6>
                                </div>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <i class="mdi mdi-account-circle me-1"></i>
                                    <span>My Account</span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <i class="mdi mdi-account-edit me-1"></i>
                                    <span>Settings</span>
                                </a>

                                <!-- item-->
                                <a href="javascript:void(0);" class="dropdown-item notify-item">
                                    <i class="mdi mdi-logout me-1"></i>
                                    <span>Logout</span>
                                </a>
                            </div>
                        </li>
                      </ul>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </header>
        <!-- HEADER Section Ends -->
     